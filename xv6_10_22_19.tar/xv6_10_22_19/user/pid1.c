#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"


//This is the function that we are using to call the getpid() function that we are using to test our syscall
int
main(int argc, char *argv[])
{
  printf(1, "My PID is: %d\n", getpid() );
  exit();
}
