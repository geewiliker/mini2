/*#include "stat.h"
#include "pstat.h"
#include "user.h"

#define N 64

int minitest2(void)
{
  struct pstat p;
  int i;
  for(i = 0; i < N; i++){
    p.pid[i] = 0;
    p.inuse[i] = 0;
    p.tickets[i] = 0;
    p.ticks[i] = 0;
    p.passvalue[i] = 0;
    p.stride[i] = 0;
  }

  int pInfo = getpinfo(&p);
  printf(2, "Processes :\n");
  for(i = 0; i < N; i++){
    printf(2, "Process: pid: %d inuse: %d tickets: %d ticks: %d passvalue %d stride %d\n", p.pid[i], p.inuse[i], p.tickets[i], p.ticks[i], p.passvalue[i], p.stride[i]);
  }
  return pInfo;
}

int main(void)
{
  minitest2();
  exit();
}
*/
