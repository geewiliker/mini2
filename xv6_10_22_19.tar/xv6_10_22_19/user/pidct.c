#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"

//This is the tester function that we used to call the getpidcount() syscall that we defined 
int
main(int argc, char *argv[])
{
  printf(1, "PID count: %d\n", getpidcount());
  exit();
}
