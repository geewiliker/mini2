#include "types.h"
#include "stat.h"
#include "pstat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int i, bryan;
  double x = 0;

  bryan = 0;
  for(i = 0; i < 5; i++){
    bryan = fork();
    if(bryan < 0){
      printf(1, "Not able to fork process.\n");
      return -1;
    }
    else if(bryan == 0){
      settickets(i * 10);
      printf(1, "%d forked child %d \n", getpid(), bryan);
      for(;;){
        x++;
      }
    }
  }
  exit();
}
